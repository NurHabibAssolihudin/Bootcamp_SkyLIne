# Di dalam sini tersimpan data mengenai user yang sedang aktif
current_user = {}