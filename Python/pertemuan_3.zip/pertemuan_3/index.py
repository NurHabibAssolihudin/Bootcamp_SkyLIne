# Ini adalah tampilan utama

# Import
from control_system import lamanAwal

# Tampil
lamanAwal()